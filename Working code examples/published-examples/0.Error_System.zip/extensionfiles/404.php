Sorry page not available <br>

<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "php-simple-login";

	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}

	$browser = '';
    $ua = strtolower($_SERVER['HTTP_USER_AGENT']);
    if (preg_match('~(?:msie ?|trident.+?; ?rv: ?)(\d+)~', $ua, $matches)) $browser = 'ie ie'.$matches[1];
    elseif (preg_match('~(safari|chrome|firefox)~', $ua, $matches)) $browser = $matches[1];
	
	$sql = "INSERT INTO log (failed, details)
	VALUES ('404', '$browser')";
    $conn->query($sql);

?>

<a href="index.php">Home</a>