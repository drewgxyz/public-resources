<?php

session_start();

if ($_SESSION["login"] === "true")
	{
		echo "You are now logged in, nice one! <br>";
	} else {
		
		header("Location: http://localhost/");
		
	}
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "php-simple-login";

	$conn = mysqli_connect($servername, $username, $password, $dbname);

	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$sql = "SELECT id, failed, details FROM log";
	$result = mysqli_query($conn, $sql);
	$rowcount=mysqli_num_rows($result);
	
	if (mysqli_num_rows($result) > 0) {
		// output data of each row
		while($row = mysqli_fetch_assoc($result)) {
			echo "id: " . $row["id"]. " - Type of error: " . $row["failed"]. " " . $row["details"]. "<br>";
		}
	} else {
		echo "0 results";
	}
	echo "Total errors:" . $rowcount . "<br>";
	
	
?>

<a href="adduser.php">Add user</a><br>
<a href="logout.php">Logout</a>