<!doctype html>
<html lang="en">
  <head>
    <title>Login</title>
  </head>
  <body>
    
    <form action="process.php" method="post">
        <label for="emailAddress">Email Address</label><br>
        <input type="text" name="email" required><br>
        <label for="password">Password:</label><br>
        <input type="text" name="password" required>
        <input type="submit" value="Submit">
    </form>

  </body>
</html>