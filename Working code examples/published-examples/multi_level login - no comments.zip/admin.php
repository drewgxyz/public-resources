<?php

session_start();

if ($_SESSION["login"] !== "true" || $_SESSION["lvl"] != "0")
	{
		
		header("Location: http://localhost/user.php");
		
	} else {
		
		echo "You are now logged in admin, nice one! <br>";
		
	}
	
?>

<a href="adduser.php">Add user</a><br>
<a href="logout.php">Logout</a>