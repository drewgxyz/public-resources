<?php
session_start();

if ($_SESSION["login"] === "true")
	{
		
		echo "Welcome to the user page!<br>";
		echo "You are now logged in " . $_SESSION["name"] .", nice one! <br>";
		
	} else {
		
		header("Location: http://localhost/");
		
	}
	
?>

<a href="logout.php">Logout</a>