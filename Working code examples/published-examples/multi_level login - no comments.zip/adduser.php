<?php
session_start();

if ($_SESSION["login"] !== "true" || $_SESSION["lvl"] !== "0")
	{
		header("Location: http://localhost/user.php");
	} 
	
?>

<?php

if($_SERVER['REQUEST_METHOD'] == 'POST') {
 
	$name = $_POST["name"];
 	$email = $_POST["email"];
	$passwd = $_POST["passwd"];
	$lvl = $_POST["lvl"];
	
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "php-simple-login";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "INSERT INTO users (name, email, password, lvl)
	VALUES ('$name', '$email', '$passwd', '$lvl')";
    $conn->query($sql);
    
	if($conn)
	{
	echo "Successfully added new user<br>";
	}else{
	echo "There was a problem, please try again<br>";
	}
	
?>	

	<a href="adduser.php">Add more users</a>

<?php
    exit();
    }
?>

<!doctype html>
<html lang="en">
<head>
<title>Add users</title>
</head>
<body>

    <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
		<label for="Name">Username</label><br>
        <input type="text" name="name" required><br>
        <label for="emailAddress">Email Address</label><br>
        <input name="email" type="email" required><br>
        <label for="password">Password:</label><br>
        <input type="text" name="passwd" required><br>
		<label for="Level">User Level: 0 = Admin, 1 = User</label><br>
        <input type="text" name="lvl" required><br>
        <input type="submit" value="Submit">
    </form>
	
	<br>
	<a href="adduser.php">Add user</a><br>
	<a href="logout.php">Logout</a>

</body>
</html>

