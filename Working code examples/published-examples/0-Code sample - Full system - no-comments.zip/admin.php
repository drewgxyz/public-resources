<?php

session_start();

if ($_SESSION["login"] === "true")
	{
		echo "You are now logged in, nice one! <br>";
	} else {
		
		header("Location: http://localhost/");
		
	}
	
?>

<a href="adduser.php">Add user</a><br>
<a href="logout.php">Logout</a>